#include "EBO.hpp"

EBO::EBO(std::vector <GLuint> indices,GLenum mode)
{
	bufferMode=mode;
	bufferSize=indices.size()*sizeof(GLuint);
	glGenBuffers(1,&ID);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ID);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,indices.size()*sizeof(GLuint),indices.data(),bufferMode);
}

void EBO::updateData(std::vector<GLuint> newData)
{
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ID);
	if((newData.size()*sizeof(GLuint))!=bufferSize){
		glBufferData(GL_ELEMENT_ARRAY_BUFFER,newData.size()*sizeof(GLuint),newData.data(),bufferMode);
		bufferSize = newData.size()*sizeof(GLuint);
	}else{
		void* ptr = glMapBuffer(GL_ELEMENT_ARRAY_BUFFER, GL_WRITE_ONLY);
		if(ptr!=NULL)
		{
			memcpy(ptr, newData.data(), newData.size()*sizeof(unsigned int));
			glUnmapBuffer(GL_ELEMENT_ARRAY_BUFFER);
		}else{
			std::cout<<"Impossible to map buffer EBO:"<<ID<<std::endl;
			GLenum tmp;
			while((tmp = glGetError())!=GL_NO_ERROR)
			{
				std::cout<<"GL error:"<<tmp<<std::endl;
			}
		}
	}
}

void EBO::Bind()
{
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ID);
}

void EBO::Unbind()
{
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
}
unsigned int EBO::GetBufSize()
{
	return bufferSize;
}

EBO::~EBO()
{
	glDeleteBuffers(1,&ID);
}


