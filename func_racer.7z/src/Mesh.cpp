#include "Mesh.hpp"

Mesh::Mesh(std::vector<GLuint> indices,GLfloat* vertData,std::vector <unsigned int> connect_order,FontLoader writer,GLenum mode,GLsizeiptr dataSize)
{
	vao.Bind();
	fontPlates.push_back(writer);
	points = indices;
	vbo =new VBO(vertData,mode,dataSize);
	ebo =new EBO(indices,mode);
	std::cout<<"Mesh ebo:"<<ebo->ID<<std::endl;
	numsPerVert=0;
	unsigned int offset=0,stride=0;
	for(long long unsigned int i=0;i<connect_order.size();i++)
	{
		stride+=connect_order[i]==2?2*sizeof(GLfloat):3*sizeof(GLfloat);
		numsPerVert+=connect_order[i]==2?2:3;
	}
	for(long long unsigned int i=0;i<connect_order.size();i++)
		switch(connect_order[i])
		{
			//vertex coords
			case 0:
				vao.Link_attrib(*vbo, i, 3, GL_FLOAT, (GLsizeiptr)stride, (void*)(long)offset);
				offset+=3*sizeof(GLfloat);
			break;
			//vertex color
			case 1:
				vao.Link_attrib(*vbo, i, 3, GL_FLOAT, (GLsizeiptr)stride, (void*)(long)offset);
				offset+=3*sizeof(GLfloat);
			break;
			//vertex texture coordinats
			case 2:
				vao.Link_attrib(*vbo, i, 2, GL_FLOAT, (GLsizeiptr)stride, (void*)(long)offset);
				offset+=2*sizeof(GLfloat);
			break;
			//vertex normals
			case 3:
				vao.Link_attrib(*vbo, i, 3, GL_FLOAT, (GLsizeiptr)stride, (void*)(long)offset);
				offset+=3*sizeof(GLfloat);
			break;
			//something unknown
			default:
				std::cout<<"Invalid connect index!"<<std::endl;
		}
	vao.Unbind();
	vbo->Unbind();
	ebo->Unbind();
}

void Mesh::UpdateData(std::vector<GLuint> newInd,GLfloat* newData,GLsizeiptr sizeofData)
{
	vao.Bind();
	points = newInd;
	vbo->updateData(newData, sizeofData);
	ebo->updateData(newInd);
}

void Mesh::Connect(ShaderProgram& shader)
{
	shader.Enable();
	vao.Bind();
	for(int i = 0;i<fontPlates.size();i++)
	{
		fontPlates[i].texUnit(shader,std::string("font"+std::to_string(i)).c_str(), i);
		fontPlates[i].Bind();
	}
}
void Mesh::Draw(ShaderProgram& shader,Camera cam,glm::vec3 translation)
{
	shader.Enable();
	cam.Matrix(45.0f, 0.1f, 100.0f, shader, "camMatrix");
	glUniform3fv(glGetUniformLocation(shader.ID,"camPos"),1,glm::value_ptr(cam.Position));
	glm::mat4 transl = glm::translate(glm::mat4(1.0f), translation);
	glUniformMatrix4fv(glGetUniformLocation(shader.ID,"translate"),1,GL_FALSE,glm::value_ptr(transl));
	vao.Bind();

	glDrawElements(GL_TRIANGLES, points.size(), GL_UNSIGNED_INT,0);
}

void Mesh::ConnectDraw(ShaderProgram& shader,Camera cam,glm::vec3 translation)
{
	shader.Enable();
	vao.Bind();
	for(int i = 0;i<fontPlates.size();i++)
	{
		fontPlates[i].texUnit(shader,std::string("font"+std::to_string(i)).c_str(), i);
		fontPlates[i].Bind();
	}

	shader.Enable();
	cam.Matrix(45.0f, 0.1f, 100.0f, shader, "camMatrix");
	glUniform3fv(glGetUniformLocation(shader.ID,"camPos"),1,glm::value_ptr(cam.Position));
	glm::mat4 transl = glm::translate(glm::mat4(1.0f), translation);
	glUniformMatrix4fv(glGetUniformLocation(shader.ID,"translate"),1,GL_FALSE,glm::value_ptr(transl));
	vao.Bind();

	glDrawElements(GL_TRIANGLES, points.size(), GL_UNSIGNED_INT,0);
}

void Mesh::FreeSpace()
{
	delete vbo;
	delete ebo;
}
