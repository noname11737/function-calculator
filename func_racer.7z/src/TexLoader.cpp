#include "TexLoader.hpp"

#define STB_IMAGE_IMPLEMENTATION
#include <stb/stb_image.h>

std::vector<GLuint> FontLoader::getIndices(double value)
{
	std::ostringstream strObj;
	strObj<<value;
	std::string convert (strObj.str());
	std::vector<GLuint> ans;
	for(int i=0;i<convert.size();i++)
	{
		ans.push_back(i*4);
		ans.push_back(2+i*4);
		ans.push_back(1+i*4);

		ans.push_back(i*4);
		ans.push_back(2+i*4);
		ans.push_back(3+i*4);
	}
	return ans;
}

GLfloat* FontLoader::to_coords(double value)
{
	std::ostringstream strObj;
	strObj<<value;
	std::string convert =strObj.str();
	GLfloat* ptr = new GLfloat[convert.size()*4*(3+2) + 1];
	ptr[0] = (GLfloat)(convert.size()*4*(3+2)*sizeof(GLfloat));
	GLfloat last_pt=0.0f;
	for(int i=0;i<convert.size();i++)
	{
		unsigned int* symb =fontMap[convert[i]];
		float mult = (float)(symb[1]-symb[3])/(symb[2]-symb[0]);
		for(int j =0;j<4;j++)
		{
			last_pt+=j==2?2*(1.0f/mult):0;
			GLfloat* stride = ptr+1+i*20+j*5;
			stride[0]=last_pt;//x
			stride[1]=((j==0||j==3)?-1:1);//y
			stride[2]=0.0f;//z
			stride[3]=(j==0||j==1)?((GLfloat)symb[0]/width):((GLfloat)symb[2]/width);//tex x
			stride[4]=(j==0||j==3)?((GLfloat)symb[3]/height):((GLfloat)symb[1]/height);//tex y
		}
	}
	return ptr;
}

FontLoader::FontLoader(const char* filename,GLuint slot,std::string letters)
{
	storedLetters = letters;
	int widthImg,heightImg,numColCh;
		stbi_set_flip_vertically_on_load(true);
		unsigned char* bytes = stbi_load(filename,&widthImg,&heightImg,&numColCh,0);
		width= widthImg;
		height=heightImg;

		int n=0;
		for(int j =0;j<height;j++)
		{
			for(int i =0;i<width;i++)
			{
				unsigned char* pixelOffset = bytes+(i + width * j)*numColCh;
				if((int)pixelOffset[0]==255&&(int)pixelOffset[1]==0&&(int)pixelOffset[2]==0)
				{
					if(n<14)
					{
						unsigned int* tmp=new unsigned int[4];
						tmp[1]=height-j;//row
						tmp[0]=i;//column
						std::map<char,unsigned int*>::iterator tIns = fontMap.begin();
						fontMap.insert(tIns,std::pair<char,unsigned int*>(storedLetters[n],tmp));
						n++;
					}else{
						fontMap.at(storedLetters[n%14])[3]=height-j;//row
						fontMap.at(storedLetters[n%14])[2]=i;//column
						n++;
					}
					pixelOffset[0]=0;
				}
			}
		}

		glGenTextures(1,&ID);
		glActiveTexture(GL_TEXTURE0 + slot);
		unit=slot;
		glBindTexture(GL_TEXTURE_2D,ID);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT);
		std::cout<<"image:"<<filename <<"\nResolution:"<< width <<"x"<< height <<std::endl;
		switch(numColCh){
			case 1:
				glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,widthImg,heightImg,0,GL_RED,GL_UNSIGNED_BYTE,bytes);
			break;

			case 3:
				glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,widthImg,heightImg,0,GL_RGB,GL_UNSIGNED_BYTE,bytes);
			break;

			case 4:
				glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,widthImg,heightImg,0,GL_RGBA,GL_UNSIGNED_BYTE,bytes);
			break;

			default:
				throw std::invalid_argument("Invalid number of color channels");
		}

		glGenerateMipmap(GL_TEXTURE_2D);
		std::cout<<"color channel number:"<<numColCh<<std::endl;
		std::map<char,unsigned int*>::iterator it = fontMap.begin();
			for(it;it!=fontMap.end();it++)
				std::cout<<it->first<<" - bot:"<< it->second[0]<<":"<< it->second[1]<<"/top:"<< it->second[2]<<":"<<it->second[3]<<std::endl;
		stbi_image_free(bytes);
		double a = 3.8766235e23;
		glBindTexture(GL_TEXTURE_2D,0);
}

void FontLoader::texUnit(ShaderProgram& program,const char* uniform,GLuint unit)
{
	GLuint texUni = glGetUniformLocation(program.ID,uniform);
	program.Enable();
	glUniform1i(texUni,unit);
}

void FontLoader::Bind()
{
	glActiveTexture(GL_TEXTURE0+unit);
	glBindTexture(GL_TEXTURE_2D,ID);
}

void FontLoader::Unbind()
{
	glBindTexture(GL_TEXTURE_2D,0);
}

void FontLoader::DeleteFont()
{
	glDeleteTextures(1, &ID);
	std::cout<<"Texture #"<<ID<<" was deleted"<<std::endl;
	std::map<char,unsigned int*>::iterator it = fontMap.begin();
	for(it;it!=fontMap.end();++it)
		delete[] it->second;
	std::cout<<"Font map:"<<storedLetters<<" was deleted!"<<std::endl;
}
