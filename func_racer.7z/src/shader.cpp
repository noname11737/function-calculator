#include "shader.h"

ShaderProgram::ShaderProgram(const char* vertexFile,const char* fragmentFile,const char* geometryFile)
{
	unsigned int vertexShader,fragmentShader,geometryShader;
	std::string vertCode=getFileContents(vertexFile);
	const char* vertexShaderSource = vertCode.c_str();
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader,1,&vertexShaderSource,NULL);
	glCompileShader(vertexShader);
	checkCompileStatus(vertexShader, "VERTEX");

	std::string fragCode=getFileContents(fragmentFile);
	const char* fragmentShaderSource = fragCode.c_str();
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader,1,&fragmentShaderSource,NULL);
	glCompileShader(fragmentShader);
	checkCompileStatus(fragmentShader, "FRAGMENT");

	if(geometryFile!=NULL)
	{
		std::string geomCode=getFileContents(geometryFile);
		const char* geometryShaderSource = geomCode.c_str();
		geometryShader = glCreateShader(GL_GEOMETRY_SHADER);
		glShaderSource(geometryShader,1,&geometryShaderSource,NULL);
		glCompileShader(geometryShader);
		checkCompileStatus(geometryShader, "GEOMETRY");
	}
	ID = glCreateProgram();
	glAttachShader(ID,vertexShader);
	glAttachShader(ID,fragmentShader);
	if(geometryFile!=NULL)
		glAttachShader(ID,geometryShader);
	glLinkProgram(ID);
	checkCompileStatus(ID, "PROGRAM");

	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);
	if(geometryFile!=NULL)
		glDeleteShader(geometryShader);
}

void ShaderProgram::checkCompileStatus(unsigned int ch_id,const char* type)
{
	int  success;
	char infoLog[512];
	if(type!="PROGRAM")
	{
		glGetShaderiv(ch_id, GL_COMPILE_STATUS, &success);
		if(!success)
		{
		    glGetShaderInfoLog(ch_id, 512, NULL, infoLog);
		    std::cout << "ERROR::SHADER::"<<type<<"::COMPILATION_FAILED\n" << infoLog << std::endl;
		}
	}else{
		glGetProgramiv(ch_id, GL_LINK_STATUS, &success);
		if(!success) {
		    glGetProgramInfoLog(ch_id, 512, NULL, infoLog);
		    std::cout << "ERROR::"<< type <<"::LINKING_FAILED\n" << infoLog << std::endl;
		}
	}
}

std::string ShaderProgram::getFileContents(const char* filename)
{
	std::ifstream in(filename,std::ios::binary);
		if(in){
			std::string contents;
			in.seekg(0, std::ios::end);
			contents.resize(in.tellg());
			in.seekg(0, std::ios::beg);
			in.read(&contents[0], contents.size());
			in.close();
			return contents;
		}
		throw(errno);
}

void ShaderProgram::Enable()
{
	glUseProgram(ID);
}

ShaderProgram::~ShaderProgram(){
	glDeleteProgram(ID);
	std::cout<<"SHADER PROGRAM "<<ID<<" DELETED!"<<std::endl;
}
