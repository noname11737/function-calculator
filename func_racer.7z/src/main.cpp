#define GLEW_STATIC
//cpp libs
#include <iostream>
#include <vector>
#include <typeinfo>
#include <fstream>
//IMGUI libs
#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

//GL libs
#include <glew.h>
#include <GLFW/glfw3.h>
//glm
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/scalar_multiplication.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/rotate_vector.hpp>

#include <json/json.h>

//project libs
#include "generator_core.hpp"
#include "shader.h"
#include "VAO.hpp"
#include "VBO.hpp"
#include "EBO.hpp"
#include "camera.hpp"
#include "TexLoader.hpp"
#include "Mesh.hpp"
#include "planeObject.hpp"

//#include "translator.cpp"
//									bot-left		bot-right		top-left	top-right
void updateNotes(Mesh** to_upd,GLfloat* l,FontLoader* writer);
void procInputs(GLFWwindow* window,glm::vec2* rect);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

//viewed rectangle
glm::vec2 func_rect[]={
	//min x - min y
	glm::vec2(-6.0,-6.0),
	//max x max y
	glm::vec2(6.0,6.0),
	glm::vec2(0.0)
};
//flag that shows if min & max values should be updated at the same time with new function
bool rescale=true;
float bg_color[] = {0.0f,0.0f,0.0f,1.0f};
//2d area of translation
glm::vec2 da[]={glm::vec2(-1.0f),glm::vec2(1.0f)};

//coordinate system:
std::vector<glm::vec3> coords={
		glm::vec3(-1.0f,-0.5f,-1.0f),
		glm::vec3(1.0f,-0.5f,-1.0f),
		glm::vec3(-1.0f,0.5f,-1.0f),
		glm::vec3(-1.0f,-0.5f,1.0f)
};

std::vector<GLuint> coordInd={0,1,0,2,0,3};

std::vector<glm::vec3> Tcoords={
		glm::vec3(-1.0f,-0.5f,0.0f),
		glm::vec3(1.0f,-0.5f,0.0f),
		glm::vec3(-1.0f,0.5f,0.0f),
		glm::vec3(1.0f,0.5f,0.0f)
};

std::vector<GLuint> TcoordInd={0,1,2,1,2,3};

std::vector <plate*> functions;
std::vector <float*> colors;
std::vector <char*> text_buffers;

bool add_function(char* function,float* color,unsigned int res);
void delete_function();

bool save(const char* filename);
bool download(char* filename);

int main()
{
	if(!glfwInit()){
		std::cout<<"Error while initing GLFW!"<<std::endl;;
		return -1;
	}
	//for full screen mode
	const GLFWvidmode* mode = glfwGetVideoMode(glfwGetPrimaryMonitor());
	//creating window
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	glfwWindowHint(GLFW_RED_BITS, mode->redBits);
	glfwWindowHint(GLFW_GREEN_BITS, mode->greenBits);
	glfwWindowHint(GLFW_BLUE_BITS, mode->blueBits);
	glfwWindowHint(GLFW_REFRESH_RATE, mode->refreshRate);

	GLFWwindow* window = glfwCreateWindow(mode->width,mode->height,"main.cpp",glfwGetPrimaryMonitor(),NULL);
	if(!window){
		std::cout<<"Error while creating window!"<<std::endl;
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	//callbacks
	glfwSetScrollCallback(window, scroll_callback);

	//glew setup
	glewExperimental = GL_TRUE;
	GLenum err = glewInit();
	if(GLEW_OK!=err){
		std::cout<<"Error while GLEW init!"<<std::endl;
		std::cout<<glewGetErrorString(err)<<std::endl;
		glfwTerminate();
		return -1;
	}
	glViewport(0, 0,mode->width,mode->height);

	char default_function[255]="0";
	float default_color[4]={1.0f,0.937f,0.0f,1.0f};
	int n_div=100;
	bool built;
	int fNumber=1;

	if(!download("test.json")){
	//function mesh
	plate::rescale_minmax=true;
		if(!add_function(default_function, default_color, n_div)){
			std::cout<<"Function built with errors!"<<std::endl;
			return -1;
		}
	}
	fNumber= functions.size();
	for(int i=0;i<functions.size();i++)
		functions[i]->updateData();
	//coords
	VAO svao;
	VBO svbo(coords,GL_STATIC_DRAW);
	EBO sebo(coordInd);

	svao.Link_attrib(svbo, 0, 3, GL_FLOAT, 3*sizeof(float), (void*)0);

	svao.Unbind();
	svbo.Unbind();
	sebo.Unbind();

	//tmp texture
	VAO tvao;
	VBO tvbo(Tcoords,GL_STATIC_DRAW);
	EBO tebo(TcoordInd);

	tvao.Link_attrib(tvbo, 0, 3, GL_FLOAT, 3*sizeof(float), (void*)0);

	tvao.Unbind();
	tvbo.Unbind();
	tebo.Unbind();

	//shader program generation
	//for plane drawing
	ShaderProgram coordsSystem("shaders/coords.vert","shaders/coords.frag","shaders/coords.geom");
	ShaderProgram numbers("shaders/texture.vert","shaders/texture.frag");

	coordsSystem.Enable();
	glUniform3fv(glGetUniformLocation(coordsSystem.ID,"zero_point"),1,glm::value_ptr(coords[0]));
	//texture loading
	FontLoader font1("textures/font1.png",0,"0123456789e.+-");

	Mesh** notes = new Mesh*[21];
	GLfloat* len = new GLfloat[21];
	//axis marks generation
	for(int i =0;i<3;i++)
	{
		double stPos;
		double divider;
		switch(i){
		//x-axis
			case 0:
				stPos =func_rect[0].x;
				divider =(func_rect[1].x-func_rect[0].x)/6;
			break;
		//y axis
			case 1:
				stPos =func_rect[2].x;
				divider =(func_rect[2].y-func_rect[2].x)/6;
			break;
		//z axis
			case 2:
				stPos =func_rect[0].y;
				divider =(func_rect[1].y-func_rect[0].y)/6;
			break;
		}
		for(int j =0;j<7;j++)
		{
			double number = glm::abs((stPos)+divider*j)>(divider/1e3)?((stPos)+divider*j):0.0;
			GLfloat* numbData = font1.to_coords(number);
			std::vector<GLuint> numbInd = font1.getIndices(number);
			GLsizeiptr size= (GLsizeiptr)numbData[0];
			std::vector<unsigned int> order ={0,2};
			Mesh* text = new Mesh(numbInd,numbData+1,order,font1,GL_DYNAMIC_DRAW,size);
			notes[i*7+j]=text;
			len[i*7+j] = (numbData+1)[(size/sizeof(GLfloat))-5];
			std::cout<<number<<" - length(x):"<<len[i*7+j]<<std::endl;
			delete[] numbData;
		}
	}
	//camera object
	Camera cam(mode->width,mode->height,glm::vec3(-2.5f,2.5f,-2.5f));

	std::cout<<mode->width<<"x"<<mode->height<<std::endl;
	//main cycle
	glEnable(GL_DEPTH_TEST);
	glm::vec2 prFunc = func_rect[0];

	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();(void) io;
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 330");

	bool updateFlag=true;
	char* fname = new char[255];
	while(!glfwWindowShouldClose(window))
	{
		glClearColor(bg_color[0],bg_color[1],bg_color[2],bg_color[3]);
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

		ImGui_ImplOpenGL3_NewFrame();
		ImGui_ImplGlfw_NewFrame();
		ImGui::NewFrame();

		font1.Bind();
		prFunc = func_rect[0];
		if(!io.WantCaptureMouse)
		{
			procInputs(window,&func_rect[0]);
			cam.Inputs(window);
			updateFlag = func_rect[0]!=prFunc;
		}
		glBindVertexArray(svao.ID);
		coordsSystem.Enable();
		cam.Matrix(45.0f, 0.1f, 100.0f, coordsSystem, "camMatrix");
		glUniform3fv(glGetUniformLocation(coordsSystem.ID,"camPos"),1,glm::value_ptr(cam.Position));
		glUniform1i(glGetUniformLocation(coordsSystem.ID,"division_number"),5);
		glDrawElements(GL_LINES,coordInd.size(), GL_UNSIGNED_INT,0);
		//update displayed data if viewed function rectangle moved
		if(updateFlag){
			//generate new plane
			plate::rescale_minmax=true;
			//gen unnormalized data
			for(int i=0;i<functions.size();i++)
				functions[i]->genValues();
			//normalize ang show
			for(int i=0;i<functions.size();i++)
				functions[i]->updateData();
			//update axis notes
			updateNotes(notes,len,&font1);
		}

		for(int i=0;i<functions.size();i++)
			functions[i]->draw(&cam,colors[i]);

		for(unsigned int j=0;j<3;j++){
			glm::vec3 tranDiv = (coords[j+1]-coords[0])/6;
			numbers.Enable();
			glUniform3fv(glGetUniformLocation(numbers.ID,"color"),1,glm::value_ptr(glm::vec3(j==0?1.0f:0.0f,j==1?1.0f:0.0f,j==2?1.0f:0.0f)));
			glUniform1i(glGetUniformLocation(numbers.ID,"ind"),j+1);
			for(int i =0;i<7;i++)
			{
				glUniform1f(glGetUniformLocation(numbers.ID,"leng"),len[j*7+i]);
				notes[j*7+i]->ConnectDraw(numbers, cam, (coords[0]+(j==0?glm::vec3(0.0f,0.0f,-0.1f):(j==2?glm::vec3(-0.1f,0.0f,0.0f):glm::vec3(-0.1f,0.0f,-0.1f)))/2)+i*tranDiv);
			}
		}

		ImGui::Begin("View settings");
		ImGui::InputInt("Net resolution",&n_div,1,2);
		if(ImGui::InputInt(" - Function number", &fNumber, 1, 1))
		{
			fNumber = fNumber<1?1:fNumber>4?4:fNumber;
			if(fNumber>functions.size())
				add_function(default_function, default_color, n_div);
			if(fNumber<functions.size())
				delete_function();
			updateFlag=true;
		}
		for(int i=0;i<functions.size();i++)
		{
			ImGui::PushID(i);
			ImGui::InputText(" - Used function", text_buffers[i], 255);
			ImGui::ColorEdit4(" - Function color",colors[i]);
			ImGui::PopID();
		}
		if(ImGui::InputFloat("bot-left x", glm::value_ptr(func_rect[0]))||
		ImGui::InputFloat("bot-left y", glm::value_ptr(func_rect[0])+1)||
		ImGui::InputFloat("top-right x", glm::value_ptr(func_rect[1]))||
		ImGui::InputFloat("top-right y", glm::value_ptr(func_rect[1])+1))
		{
			plate::rescale_minmax=true;
			for(int i=0;i<functions.size();i++)
				functions[i]->genValues();
			for(int i=0;i<functions.size();i++)
				functions[i]->updateData();
			updateNotes(notes,len,&font1);
		}

		if(ImGui::Button("Apply changes"))
		{
			for(int i=0;i<functions.size();i++)
			{
			if(functions[i]->usedFunc.compare(std::string(text_buffers[i]))!=0)
			{
				updateFlag=true;
				functions[i]->updateFunction(std::string(text_buffers[i]), &built);
				if(!built)
					return -1;
			}
			}
		}
		ImGui::ColorEdit4("- background color",bg_color);

		ImGui::Text("File management:");
		ImGui::InputText(" - File name", fname, 255);
		if(ImGui::Button("Save"))
			save(fname);
		ImGui::SameLine();
		if(ImGui::Button("Download"))
		{
			download(fname);
			updateFlag=true;
		}

		ImGui::End();

		ImGui::Render();
		ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	delete[] fname;
	ImGui_ImplOpenGL3_Shutdown();
	ImGui_ImplGlfw_Shutdown();
	ImGui::DestroyContext();

	for(int i=0;i<21;i++)
	{
		notes[i]->FreeSpace();
		delete notes[i];
	}
	delete notes;
	delete[] len;
	font1.DeleteFont();
	glfwDestroyWindow(window);
	glfwTerminate();
	save("test.json");
	return 0;
}

bool add_function(char* function,float* color,unsigned int res)
{
	bool result;
	char inx = functions.size();
	text_buffers.push_back(new char[255]);
	colors.push_back(new float[4]);
	memcpy(text_buffers[inx],function,255*sizeof(char));
	memcpy(colors[inx],color,4*sizeof(float));
	functions.push_back(new plate (std::string(text_buffers[inx]),&result,res,da,&func_rect[0]+2,func_rect,"shaders/plane.vert","shaders/plane.frag","shaders/plane.geom"));
	return result;
}

void delete_function()
{
	char inx = functions.size()-1;
	delete[] text_buffers[inx];
	delete[] colors[inx];
	delete functions[inx];
	colors.pop_back();
	text_buffers.pop_back();
	functions.pop_back();
}

void procInputs(GLFWwindow* window,glm::vec2* rect)
{
	GLfloat speed=0.003;
	if(glfwGetKey(window, GLFW_KEY_ESCAPE)==GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	if(glfwGetKey(window, GLFW_KEY_UP)==GLFW_PRESS)
	{
		rect[0].y-=speed;
		rect[1].y-=speed;
	}
	if(glfwGetKey(window, GLFW_KEY_DOWN)==GLFW_PRESS)
	{
		rect[0].y+=speed;
		rect[1].y+=speed;
	}
	if(glfwGetKey(window, GLFW_KEY_RIGHT)==GLFW_PRESS)
	{
		rect[0].x+=speed;
		rect[1].x+=speed;
	}
	if(glfwGetKey(window, GLFW_KEY_LEFT)==GLFW_PRESS)
	{
		rect[0].x-=speed;
		rect[1].x-=speed;
	}
}

void updateNotes(Mesh** to_upd,GLfloat* l,FontLoader* writer){
	for(unsigned int i=0;i<3;i++)
	{
		double stVal,divider;
		int st_inx;
		switch(i){
		case 0:
			st_inx = 0;
			stVal = func_rect[0].x;
			divider = (func_rect[1].x - func_rect[0].x)/6.0f;
			break;
		case 1:
			st_inx = 14;
			stVal = func_rect[0].y;
			divider = (func_rect[1].y - func_rect[0].y)/6.0f;
			break;

		case 2:
			st_inx = 7;
			stVal = func_rect[2].x;
			divider = (func_rect[2].y - func_rect[2].x)/6.0f;
			break;
		}
		for(unsigned int j = 0;j<7;j++)
		{
			double value = stVal+j*divider;
			GLfloat* data = writer->to_coords(value);
			std::vector <GLuint> numbInd = writer->getIndices(value);
			to_upd[st_inx+j]->UpdateData(numbInd, (data+1), (GLsizeiptr)data[0]);
			l[st_inx+j] =  (data+1)[((int)data[0]/sizeof(GLfloat))-5];
			delete[] data;
		}
	}
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	double step = 0.5;
	bool add=(func_rect[0]-glm::vec2(step*-1*yoffset)).x < (func_rect[1]+glm::vec2(step*-1*yoffset)).x;
	func_rect[0]=func_rect[0]-(add?glm::vec2(step*-1*yoffset):glm::vec2(0.0));
	func_rect[1]=func_rect[1]+(add?glm::vec2(step*-1*yoffset):glm::vec2(0.0));
}

bool save(const char* filename)
{
	if(functions.size()==0)
	{
		std::cout<<"No functions yo save!"<<std::endl;
		return false;
	}
	using namespace nlohmann;
	json data;
	data["params"]["resolution"]=functions[0]->resol;
	data["params"]["coords"]={func_rect[0].x,
			func_rect[0].y,
			func_rect[1].x,
			func_rect[1].y,};
	data["params"]["minmax"]={func_rect[2].x,func_rect[2].y};
	for(unsigned int i=0;i<functions.size();i++){
		char name[] = "function0";
		name[8]='0'+i;
		data[name]["name"]=functions[i]->usedFunc;
		data[name]["color"]={colors[i][0],colors[i][1],colors[i][2],colors[i][3]};
	}
	std::ofstream file;
	file.open(filename,std::ofstream::out);
	file<<data;
	file.close();
	return true;
}
bool download(char* filename)
{
	std::ifstream file;
	file.open(filename, std::ifstream::in);
	using namespace nlohmann;
	try{
		json data = json::parse(file);
		file.close();

		func_rect[0]=glm::vec2(data["params"]["coords"][0],data["params"]["coords"][1]);
		func_rect[1]=glm::vec2(data["params"]["coords"][2],data["params"]["coords"][3]);
		func_rect[2]=glm::vec2(data["params"]["minmax"][0],data["params"]["minmax"][1]);

		for(unsigned int i=0;i<functions.size();i++)
			delete functions[i];
		functions.clear();
		colors.clear();
		text_buffers.clear();

		unsigned int resol = data["params"]["resolution"];
		char name[] = "function0";
		for(unsigned int i = 0;i<4;i++){
			name[8] = '0'+i;
			try{
				std::string txt = data[name]["name"];
				char* func=new char[255];
				memcpy(func,txt.c_str(),txt.size()*sizeof(char));
				func[txt.size()]='\0';
				float* color =new float[4];
				color[0]=data[name]["color"][0];
				color[1]=data[name]["color"][1];
				color[2]=data[name]["color"][2];
				color[3]=data[name]["color"][3];
				std::cout<<func<<"|	color:"<<color[0]<<","<<color[1]<<","<<color[2]<<","<<color[3]<<","<<std::endl;
				add_function(func, color, resol);
				delete[] color;
				delete[] func;
			}catch(json::exception a){
				if(a.id==302)
					break;
			}
		}
	}catch(json::exception expt){
		std::cout<<expt.what()<<std::endl;
		return false;
	}
	return true;
}
