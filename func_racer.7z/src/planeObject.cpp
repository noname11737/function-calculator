#include "planeObject.hpp"
bool plate::rescale_minmax;

void plate::genValues()
{
	data.clear();
	if(rescale_minmax)
	{
		try{
			*minmax=glm::vec2(builder->getValue(glm::value_ptr(viewedRect[0])));
		}catch(int ex)
		{
			switch(ex){
			case 3:
				*minmax=glm::vec2(0.0f);
			}
		}
	}
	rescale_minmax=false;
	glm::vec2 scl((translatedRect[1].x-translatedRect[0].x)/(viewedRect[1].x-viewedRect[0].x),(translatedRect[1].y-translatedRect[0].y)/(viewedRect[1].y-viewedRect[0].y));
	glm::vec2 trans((translatedRect[1]+translatedRect[0])/2-(viewedRect[1]+viewedRect[0])/2);
	for(unsigned int row=0;row<=resol;row++)
	{
		glm::vec2 a(viewedRect[0].x,viewedRect[0].y+row*(viewedRect[1].y-viewedRect[0].y)/resol);
		glm::vec2 b(viewedRect[1].x,viewedRect[0].y+row*(viewedRect[1].y-viewedRect[0].y)/resol);
		glm::vec2 div((b-a)/resol);
		for(unsigned int col=0;col<=resol;col++)
		{
			glm::vec2 nPoint((a+div*col+trans)*scl);
			glm::vec2 tmp(div*col+a);
			double val;
			try{
				val = builder->getValue(glm::value_ptr(tmp));
			}catch(int ex){
				switch(ex){
				case 3:
					val=0.0f;
				}
			}
			minmax[0].x=(val<minmax[0].x)?val:minmax[0].x;
			minmax[0].y=(val>minmax[0].y)?val:minmax[0].y;
			data.push_back(glm::vec3(nPoint.x,val,nPoint.y));
		}
	}
}

void plate::genPlane()
{
	minmax[0].y=(minmax[0].x==minmax[0].y)?minmax[0].x+6.0f:minmax[0].y;
	for(auto i = data.begin();i!=data.end();i++)
		i->y = -0.5+glm::abs(i->y-minmax[0].x)/glm::abs(minmax[0].y-minmax[0].x);
}

void plate::genInd()
{
	indices.clear();
	for(unsigned int i=0;i<(resol*resol);i++)
	{
		unsigned int bot = i+i/resol;
		indices.push_back(bot+resol+1);
		indices.push_back(bot+resol+2);
		indices.push_back(bot);

		indices.push_back(bot+1);
		indices.push_back(bot);
		indices.push_back(bot+resol+2);
	}
}

plate::plate(std::string fn,bool* buildFlag,unsigned int res,glm::vec2* translate_into,glm::vec2* minmaxaddr,glm::vec2* pos,const char* vertexShader,const char* fragmentShader,const char* geometryShader)
{
	usedFunc=fn;
	minmax=minmaxaddr;
	translatedRect=translate_into;
	viewedRect=pos;
	resol=res;
	std::vector <float (*)(float,float)> dubFuncs({*plus,*minus,*multi,*divid,*power});
	std::vector <float (*)(float)> sinFuncs({*sing,*cosg});
	std::vector <std::string> dubVocab({"+","-","*","/","^"});
	std::vector <std::string> sinVocab({"sin","cos"});
	std::vector <std::string> varVocab({"x","y"});
	std::vector<unsigned int> priVocab({1,1,2,2,3,4,4});
	builder = new translator<float>(usedFunc,dubFuncs.data(),dubVocab,sinFuncs.data(),sinVocab,priVocab,varVocab,buildFlag);

	genValues();
	genInd();
	vao = new VAO();
	vbo = new VBO(data,GL_DYNAMIC_DRAW);
	ebo = new EBO(indices);

	vao->Link_attrib(*vbo, 0, 3, GL_FLOAT, 3*sizeof(GLfloat), (void*)0);

	vao->Unbind();
	vbo->Unbind();
	ebo->Unbind();

	program = new ShaderProgram(vertexShader,fragmentShader,geometryShader);
}

void plate::updateData()
{
	glBindVertexArray(vao->ID);
	genPlane();
	vbo->updateData(data);
	glBindVertexArray(0);
}

void plate::updateFunction(std::string nFunc,bool* builtFlag)
{
	usedFunc = nFunc;
	builder->updateFunction(usedFunc, builtFlag);
	updateData();
}

void plate::draw(Camera* cam,float* planeColor)
{
	program->Enable();
	cam->Matrix(45.0f, 0.1f, 100.0f, *program, "camMatrix");
	glUniform4f(glGetUniformLocation(program->ID,"color"),planeColor[0],planeColor[1],planeColor[2],planeColor[3]);
	glBindVertexArray(vao->ID);
	vbo->Bind();
	ebo->Bind();
	glDrawElements(GL_TRIANGLES,indices.size(),GL_UNSIGNED_INT,0);
}

glm::vec3* plate::getDataPtr()
{
	return data.data();
}

plate::~plate()
{
	delete builder;
	delete program;
	delete vao;
	delete vbo;
	delete ebo;
}
