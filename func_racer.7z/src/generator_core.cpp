#include "generator_core.hpp"

GLfloat parabolic(float* dot)
{
	return (dot[0]*dot[0]+dot[1]*dot[1]);
}

GLfloat eggholder(float* dot)
{
	return -1*(dot[1]+47)*glm::sin(glm::radians(glm::sqrt(glm::abs(dot[1]+dot[0]/2+47))))-dot[0]*(glm::sin(glm::radians(glm::sqrt(glm::abs(dot[0]-dot[1]-47)))));
}

GLfloat pyramidal(float* dot)
{
	return (1.0/(1.0+dot[0]*dot[0]))+(1.0/(1.0+dot[1]*dot[1]));
}

GLfloat flat(float* dot)
{
	return 0.0;
}
GLfloat rise(float* dot)
{
	return dot[0]+dot[1];
}

GLfloat sinusoidal(float* dot)
{
	return glm::sin(dot[0]*dot[0] +dot[1]);
	//return glm::sin(dot[0]);
}

GLfloat multiextremal(float* dot)
{
	return dot[0]*dot[0]*glm::abs(glm::sin(glm::radians(2*dot[0])))+dot[1]*dot[1]*glm::abs(glm::sin(glm::radians(2*dot[1])))-1.0/(5*dot[0]*dot[0]+5*dot[1]*dot[1]+0.2)+5;
}

GLfloat forrandom(float* dot)
{
	return (GLfloat)rand();
}
