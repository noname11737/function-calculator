#include "VBO.hpp"

VBO::VBO(std::vector <glm::vec3> vertices,GLenum mode)
{
	bufferSize = vertices.size()*sizeof(float)*3;
	bufferData=NULL;
	bufferMode = mode;
	glGenBuffers(1,&ID);
	glBindBuffer(GL_ARRAY_BUFFER,ID);
	glBufferData(GL_ARRAY_BUFFER,vertices.size()*sizeof(float)*3,vertices.data(),mode);
}

VBO::VBO(GLfloat* data,GLenum mode,GLsizeiptr dataSize)
{
	bufferSize = dataSize;
	bufferMode = mode;
	bufferData=NULL;
	glGenBuffers(1,&ID);
	glBindBuffer(GL_ARRAY_BUFFER,ID);
	glBufferData(GL_ARRAY_BUFFER,dataSize,data,mode);
	glBindBuffer(GL_ARRAY_BUFFER,0);
}

void VBO::updateData(std::vector <glm::vec3> vertices)
{
	glBindBuffer(GL_ARRAY_BUFFER,ID);
	if(bufferMode!=GL_DYNAMIC_DRAW)
		std::cout<<"WARNING:VBO DATA MODE IS NOT GL_DYNAMIC_DRAW\nPRODUCTIVITI ISSUES MAY OCCURE!"<<std::endl;
	if((vertices.size()*3*sizeof(float)) == bufferSize)
	{
		bufferData = glMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
		memcpy(bufferData,vertices.data(),vertices.size()*3*sizeof(float));
		glUnmapBuffer(GL_ARRAY_BUFFER);
	}else{
		glBufferData(GL_ARRAY_BUFFER,vertices.size()*3*sizeof(float),vertices.data(),bufferMode);
		bufferSize = vertices.size()*3*sizeof(float);
	}
}

void VBO::updateData(GLfloat* vertices,GLsizeiptr dataSize)
{
	glBindBuffer(GL_ARRAY_BUFFER,ID);
	if(bufferMode!=GL_DYNAMIC_DRAW)
		std::cout<<"WARNING:VBO DATA MODE IS NOT GL_DYNAMIC_DRAW\nPRODUCTIVITI ISSUES MAY OCCURE!"<<std::endl;
	if(dataSize==bufferSize)
	{
		bufferData=glMapBuffer(GL_ARRAY_BUFFER,GL_WRITE_ONLY);
		memcpy(bufferData,vertices,dataSize);
		glUnmapBuffer(GL_ARRAY_BUFFER);
	}else{
		glBufferData(GL_ARRAY_BUFFER,dataSize,vertices,bufferMode);
		bufferSize = dataSize;
	}
}

void VBO::Bind()
{
	glBindBuffer(GL_ARRAY_BUFFER,ID);
}

unsigned int VBO::GetBufSize()
{
	return bufferSize;
}

void VBO::Unbind()
{
	glBindBuffer(GL_ARRAY_BUFFER,0);
}

VBO::~VBO()
{
	glDeleteBuffers(1,&ID);
}


