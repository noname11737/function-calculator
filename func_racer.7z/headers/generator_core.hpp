#define GLEW_STATIC
#ifndef GEN_CORE
#define GEN_CORE

#include <cstdlib>

#include <glew.h>
#include <glm/glm.hpp>

GLfloat parabolic(float* dot);
GLfloat eggholder(float* dot);
GLfloat pyramidal(float* dot);
GLfloat multiextremal(float* dot);
GLfloat sinusoidal(float* dot);
GLfloat flat(float* dot);
GLfloat rise(float* dot);
GLfloat forrandom(float* dot);

#endif
