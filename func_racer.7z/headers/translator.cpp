#include "translator.hpp"
float plus(float a,float b){
	return a+b;
}

float minus(float a,float b){
	return a-b;
}

float multi(float a,float b){
	return a*b;
}

float divid(float a,float b){
	return a/b;
}

float power(float a,float b){
	return glm::pow(a,b);
}


float sing(float a){
	return glm::sin(a);
}

float cosg(float a){
	return glm::cos(a);
}
