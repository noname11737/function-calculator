#define GLEW_STATIC

#ifndef MESH_CLASS_HPP
#define MESH_CLASS_HPP

#include <glew.h>

#include <vector>

#include <TexLoader.hpp>

#include "VAO.hpp"
#include "EBO.hpp"
#include "shader.h"
#include "camera.hpp"

class Mesh
{
	public:
		std::vector<unsigned int> points;
		std::vector<FontLoader> fontPlates;

		unsigned int numsPerVert;
		VAO vao;
		VBO* vbo;
		EBO* ebo;

		Mesh(std::vector<GLuint> indices,GLfloat* vertData,std::vector <unsigned int> connect_order,FontLoader writer,GLenum mode,GLsizeiptr dataSize);

		void UpdateData(std::vector<GLuint> newInd,GLfloat* newData,GLsizeiptr sizeofData);
		void Connect(ShaderProgram& shader);
		void Draw(ShaderProgram& shader,Camera cam,glm::vec3 translation);
		void ConnectDraw(ShaderProgram& shader,Camera cam,glm::vec3 translation);
		void FreeSpace();
};

#endif
