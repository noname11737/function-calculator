#define GLEW_STATIC
#ifndef VBO_H
#define VBO_H

#include <glew.h>
#include <vector>
#include <iostream>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

class VBO{
	private:
		unsigned int bufferSize;
		GLenum bufferMode;
		void* bufferData;
	public:
		unsigned int ID;

		VBO(std::vector <glm::vec3> vertices,GLenum mode);
		VBO(GLfloat* data,GLenum mode,GLsizeiptr dataSize);

		unsigned int GetBufSize();
		void updateData(GLfloat* vertices,GLsizeiptr dataSize);
		void updateData(std::vector <glm::vec3> vertices);
		void Bind();
		void Unbind();
		~VBO();
};

#endif
