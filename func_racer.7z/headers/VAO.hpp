#define GLEW_STATIC
#ifndef VAO_H
#define VAO_H

#include <glew.h>
#include "VBO.hpp"

class VAO{
	private:
	public:
		unsigned int ID;
		VAO();
		void Bind();
		void Link_attrib(VBO& vbo,GLuint layout,GLuint num_components,GLenum type,GLsizeiptr stride,void* offset);
		void Unbind();
		~VAO();
};

#endif
