#define GLEW_STATIC

#ifndef LOADER_HPP
#define LOADER_HPP
//stbi

//glm
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/scalar_multiplication.hpp>
#include <glm/gtx/string_cast.hpp>
#include <glm/gtx/rotate_vector.hpp>

#include <glew.h>
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <iostream>

#include "shader.h"
class FontLoader
{
	private:
	//for real number fonst 14*2 vec2`s:0123456789e.+-
		std::string storedLetters;
		std::map <char,unsigned int*> fontMap;
	public:

		GLuint ID;
		GLuint unit;
		unsigned int width,height;

		GLfloat* to_coords(double value);
		std::vector<GLuint> getIndices(double value);

		FontLoader(const char* filename,GLuint slot,std::string letters);

		void texUnit(ShaderProgram& program,const char* uniform,GLuint unit);
		void Bind();
		void Unbind();

		void DeleteFont();
};

#endif
