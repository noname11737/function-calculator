#define GLEW_STATIC
#ifndef EBO_H
#define EBO_H

#include <glew.h>
#include <vector>
#include <iostream>
class EBO{
	private:
		unsigned int bufferSize;
	public:
		unsigned int ID;
		GLenum bufferMode;
		EBO(std::vector <GLuint> indices,GLenum mode = GL_STATIC_DRAW);
		unsigned int GetBufSize();
		void updateData(std::vector<GLuint> newData);
		void Bind();
		void Unbind();
		~EBO();
};

#endif
