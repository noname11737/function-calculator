#define GLEW_STATIC
#ifndef SHADER_CLASS_H
#define SHADER_CLASS_H

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <cerrno>

#include <glew.h>

class ShaderProgram{
	private:
		std::string getFileContents(const char* filename);
		void checkCompileStatus(unsigned int ch_id,const char* type);
	public:
		unsigned int ID;
		ShaderProgram(const char* vertexFile,const char* fragmentFile,const char* geometryFile=NULL);
		void Enable();
		~ShaderProgram();
};

#endif
