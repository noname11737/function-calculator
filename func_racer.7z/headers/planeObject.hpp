#define GLEW_STATIC
#ifndef PLANE_HPP
#define PLANE_HPP
#include <glew.h>
#include "translator.hpp"
#include "camera.hpp"
#include "shader.h"
#include "VAO.hpp"
#include "VBO.hpp"
#include "EBO.hpp"

class plate{
private:
	//connected to outer data!
	glm::vec2* translatedRect;
	glm::vec2* viewedRect;
	glm::vec2* minmax;

	std::vector<GLuint> indices;
	std::vector<glm::vec3> data;


	//normalizes them between minimum and maximum values
	void genPlane();
	void genInd();

public:
	unsigned int resol;
	std::string usedFunc;
	//specifies if minmax value hsould be set
	static bool rescale_minmax;
	//can be deleted
	translator<float>* builder;
	ShaderProgram* program;
	VAO* vao;
	VBO* vbo;
	EBO* ebo;

	//constructor
	plate(std::string  fn,bool* buildFlag,unsigned int res,glm::vec2* translate_into,glm::vec2* minmaxaddr,glm::vec2* pos,const char* vertexShader,const char* fragmentShader,const char* geometryShader);
	//generates unnormalized values into data vector
	void genValues();
	//updates buffer data
	void updateData();
	void updateFunction(std::string nFunc,bool* builtFlag);
	glm::vec3* getDataPtr();
	//draws plane
	void draw(Camera* cam,float* planeColor);
	~plate();
};

#endif
